export default function Sobre() {
  return (
    <main className="p-10">
      <h1 className="text-2xl font-bold mb-4">Sobre o Desenvolvedor</h1>
      <p>Este aplicativo foi desenvolvido por um estudante de tecnologia, como parte de um projeto para praticar Next.js e Tailwind CSS.</p>
    </main>
  )
}
